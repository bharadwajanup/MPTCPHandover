import numpy as np
import matplotlib.pyplot as plt

WIFIIP = '192.168.0.18'
LTEIP = '172.20.10.6'
splice = 1000

def readFile(fileName, mode):
	file = open(fileName, mode)
	content = file.readlines()
	file.close()
	return content

def drawGraph(data, data1):
	fig, ax = plt.subplots()
	ax.set_color_cycle(['red', 'green'])
	plt.plot(data[1], data[0])
	plt.plot(data1[0], data1[1])
	plt.xlabel('Relative Time')
	plt.ylabel('RTT')
	plt.legend(['Single Path TCP', 'With Modified MPTCP Scheduler'], loc='upper right')
	plt.show()



def splitContents(data):
	graphData = [[],[], [],[]]
	for eachLine in data:
		splitData = eachLine.strip().split('\t')
		if splitData[1].strip() == WIFIIP:
			graphData[0].append(float(splitData[0]))
			graphData[1].append(float(splitData[2]))
		elif splitData[1].strip() == LTEIP:
			graphData[2].append(float(splitData[0]))
			graphData[3].append(float(splitData[2]))
	return graphData
''''

def split_data(data):
	items = [[], []]
	for i in range(len(data)):
		item = data[i].split(' ')
		if item[3].strip() == 'DATA':
			if i != len(data):
				next_item = data[i+1].split(' ')
				if int(next_item[1]) == int(item[1]):
					maximum = max([int(next_item[0]), int(next_item[1])])
				else:
					maximum = int(item[0].strip())
				items[0].append(maximum)
				items[1].append(int(item[1].strip()))
	return items
'''
def split_data(data):
	items = [[], []]
	for i in range(len(data)):
		item = data[i].split(' ')
		if item[2].strip() == 'Wi-Fi':
			if i < len(data) - 1:
				next_item = data[i+1].split()
				if item[1] == next_item[1]:
					maximum = max([int(item[0].strip()), int(next_item[0].strip())])
					items[0].append(maximum)
					if maximum == next_item[0].strip():
						items[1].append(int(next_item[1].strip()))
					else:
						items[1].append(int(item[1].strip()))
				else:
					items[0].append(int(item[0].strip()))
					items[1].append(int(item[1].strip()))

	return items


def split_data1(data):
	items = [[], []]
	for each_item in data:
		item = each_item.split(' ')
		items[0].append(int(item[0].strip()))
		items[1].append(int(item[1].strip()))
	return items




if __name__ == '__main__':
	fileContent = readFile('interpolated_readings (3).txt', 'r')
	file2 = readFile('blind_spot_reading (4).txt', 'r')
	#spliList = splitContents(fileContent)
	plot_data = split_data(fileContent)
	plot_data2 = split_data1(file2)
	new_plot = []


	for i in range(len(plot_data2[1])):
		tot = 0
		for j in range(0, i):
			tot += plot_data2[1][j]
		new_plot.append(tot)
	plot_data2[0] = new_plot[:]

	new_plot_inter = []
	for i in range(len(plot_data[0])):
		tot = 0
		for j in range(0, i):
			tot += plot_data[0][j]
		new_plot_inter.append(tot)
	plot_data[1] = new_plot_inter[:]

	#drawGraph(spliList)
	print(new_plot[-1])
	print(new_plot_inter[-1])
	drawGraph(plot_data, plot_data2)


from pcapfile import savefile
from pcapfile.protocols.linklayer import ethernet
from pcapfile.protocols.network import ip
import binascii

testcap = open('sample.pcap', 'rb')
capfile = savefile.load_savefile(testcap, verbose=False)
testcap.close()

try:
	timeDiffTup = tuple()
	for i in range(len(capfile.packets)):
		if i < len(capfile.packets) - 1:
			try:
				timeDiff = capfile.packets[i+1].timestamp - capfile.packets[i].timestamp
				timeDiffTup += ((timeDiff),)
				eth_frame = ethernet.Ethernet(capfile.packets[i].raw())

				#ip_packet = ip.IP(binascii.unhexlify(eth_frame.payload))
				#print(ip_packet)
				print(eth_frame)
			except:
				print 'fuck you'
				continue

	print('length', len(timeDiffTup))
	print(timeDiffTup.index(max(timeDiffTup)))

except IndexError:
	print('Index wrong')

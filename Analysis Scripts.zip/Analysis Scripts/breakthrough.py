WIFIIP = '192.168.0.18'
LTEIP = '172.20.10.6'
fileName = 'without_mptcp'

def readFile(fileName, mode):
	file = open(fileName, mode)
	content = file.readlines()
	file.close()
	return content

def findRTT(content, RTTList):
	for eachPacket in content:
		packetInfo = eachPacket.split()
		if len(packetInfo) == 10:
			RTTList.append((str(packetInfo[1]).replace('b','').replace("'",''), str(packetInfo[2]).replace('b','').replace("'",''),float(packetInfo[9]) * 1000000))
	return RTTList

def writeFile(fileName, listOfRTTs,content, mptcp = False):
	file = open(fileName, 'w')
	file.writelines("{0} \t {1} \t {2}\n".format(str(l[0]), str(l[1]), str(l[2])) for l in listOfRTTs)
	file.close()

if __name__ == '__main__':
	RTTList = list()
	content = readFile(fileName, 'rb')
	writeFile('RTTList.txt', findRTT(content, RTTList), content, True) if fileName == 'with_mptcp' else writeFile('RTTListWOMPTCP.txt', findRTT(content, RTTList), content)
